export const FLY_FAILED = 'FLY_FAILED';
export const FLY_SUCCESS = 'FLY_SUCCESS'